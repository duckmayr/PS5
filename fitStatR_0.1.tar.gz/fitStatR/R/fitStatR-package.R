#' fitStatR
#'
#' The fitStatR package calculates fit statistics for forecasting models.  
#' @name fitStatR
#' @docType package
#' @author  JB Duck-Mayr
#' @importFrom stats median na.omit
NULL
